import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActualitePage } from './actualite.page';

describe('ActualitePage', () => {
  let component: ActualitePage;
  let fixture: ComponentFixture<ActualitePage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(ActualitePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
