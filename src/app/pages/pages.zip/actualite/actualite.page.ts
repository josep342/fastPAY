import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-actualite',
  templateUrl: './actualite.page.html',
  styleUrls: ['./actualite.page.scss'],
  standalone:false
})
export class ActualitePage implements OnInit {

  //75 =titre, 200=soustitre, 650=detail


  tabTitre=["Le PDG de la C.T.I  Lance La Promotion de Carte(Carte Simple, CArte PVC)=> 15% de REDUCTION","La C.T.I reprend les Activités de Formation Professionnelle pour la Nouvelle Edition 2025 ","La Division de Marketing signal la Promotion du LOGICIEL SUPER PHARMA Tend à sa fin"]

  tabTitreCle=["Suite au Renouvellement des Outils de la C.T.I, son  PDG, ASKYAS Junior annonce La promotion Full, dans le but de faire gouter la Population Congolaise le Fruit de ce Matériau de la Nouvelle Génération","Dans la percepective cadran avec les activités organisées à la C.T.I, La division Technique a le plaisir d'annoncer le lancement  officiel de la nouvelle Edition de Formation Professionnelle Accelérée ","La Division de Marketing annonce et avertit le Public sur la promotion du Logiciel SUPER PHARMA lancée depuis la fin de l année 2024   tend deja à son terme, vus l'atteinte d'une cagnotee de Contrat"]

  tabTitreDetail=["En guise d'information comme stipuler ci-haut, en vue de Favoriser les Infrastructures,Associations, Ecoles et autres, la C.T.I offre une Opportunité de Conception et Impression de Qualité des Carte sur toutes leurs formes(Carte PVC(Carte d'élève, Carte d'étudiant, Carte de Membre, Carte de Service, autre) et Carte Simple(Carte de Visite, Carte MicroBadge) avec une qualité SUPERBE [au délà des imagination] avec une REDUCTION DE 15% du maché pour toute operation, pour plus d'info +243 970494397, okay","Pour plus d'info, La CTI offre une session de formation professionnelle dans le domaine telle que : Bureautique,(Word, Excel d'entreprise, Power Point) Infographie(Montage de Photo, Realisation de Clips VIDEO), Programmtion Informatique( Programmation de LOGICIEL DE GESTION, Programmation de SIte WEB professionnel,Programmation des App Mobile) différents LANGAGE DE PROGRAMMATION tels que PYTHON, JAVASCRIPT,PHP, * Framework Moderne tels que IONIC,ANGULAR, KIVY&KIVYMD, TOGA. Un support Technique Performant.","De prime abord, SUPER PHARMA UN logiciel multiplateforme concu par le Support Technique de la CTI, un Logiciel prenant en charge toutes les activités de la pharmacie telles que * LA GESTION DE STOCK,*GESTION DE VENTE,*GESTION DE PEREMPTION,GESTION DE PRISE EN CHARGE(gestion de prescription médicales, gestion des abonnés de la pharmacie), * OpenAI: AI intégré capable de prendre la decision selon les plaintes du malade, *STOCKAGE de données en LOCAL ou via CLOUD De Firebase*Kit Complet compte : *PROGRAMME Desktop GESTIONNAIRE Desktop, *PROGRAMME VENDEUR, App Mobile Vendeur"];

  tabImage=["/assets/images/bas3.jpg","/assets/images/bas4.png","/assets/images/c3.jpeg"];
  
  constructor() { }

  ngOnInit() {
  }

}
