import { Component, OnInit } from '@angular/core';
import { Camera,CameraResultType,CameraSource } from '@capacitor/camera';
import { ApiService } from '../api.service';
import { Router } from '@angular/router';

import { DexiAPIService } from '../dexi-api.service';


@Component({
  selector: 'app-server',
  templateUrl: './server.page.html',
  styleUrls: ['./server.page.scss'],
  standalone:false
})
export class ServerPage implements OnInit {

  constructor(private api:ApiService,private route:Router,private db:DexiAPIService) {
    
  }


  async saveIfo(){
   
    alert('ajouter')
    
  }

  dataFriend:any;
  
  async recupeUp(){

    this.dataFriend=this.db.friends.toArray();
  }

  dataaFF:any;

  async recupeUpId(){

    const data =this.db.friends.toArray()
    //.where('age').below(30).and(friends=>friends.id<2).toArray();

    if ('_value' in data){

      alert("trouvé")

      this.dataFriend= JSON.parse(JSON.stringify(data));

      this.dataaFF=this.dataFriend['_value'];

    }
    else{
      alert("vide !!")
    }
  }

  //ouverture du fichier

  testServer(){

    this.route.navigate(['/connexion']);

  }

  scanCode:any;

  async scannerQR(){

    const image=await Camera.getPhoto({
      quality:90,
      allowEditing:true,
      resultType:CameraResultType.Uri,
      source:CameraSource.Camera
    });

    this.scanCode=image.webPath;
  }

  ngOnInit() {
  }

  serverAdr:string="55555";

  i:any=1;

  saveIp(){ 
    
    this.api.saveAdressServer(this.exemp,this.serverAdr);

    this.i=this.i+1

  }

  repserve:any=false;

  testerServer(){

   
    this.repserve=this.api.testerServer(this.serverAdr);

    if(this.repserve==true){

      this.route.navigate(['/connexion']);

    }
    else{
      alert("Serveur Injoignable, veuillez bien saisir l adresse du serveur ou consulter votre Admin le problem persiste")
    }
    
  }
  
  dataRep:any;
  exemp:any;

  dataRepp:any;

  dataAll:any;
  
  recupServer(){
    
    this.dataRepp=this.api.get(this.exemp);

    this.dataAll=this.dataRepp.__zone_symbol__state;

   
  }

  getTousKeys(){
    
    this.dataRepp=this.api.getTousKey();

  }


  deleteServer(){
    
    this.dataRep=this.api.clearBd();

  }


  etat:any=0;
  textBtn:any="Qr Code";

  changerModeConnexion(){

    if(this.etat==0){

      document.getElementById('cadre1')!.style.display="none";
      document.getElementById('cadre2')!.style.display="block";

      document.getElementById('cadre3')!.style.display="none";

      this.etat=1;

      this.textBtn="Adresse";
      

    }
    else{

      document.getElementById('cadre2')!.style.display="none";
      document.getElementById('cadre1')!.style.display="block";

      document.getElementById('cadre3')!.style.display="block";


      this.etat=0;
     
     
      this.textBtn="Qr Code";

    }

    

  }
}
