import { Component, OnInit,viewChild,ElementRef } from '@angular/core';
import {Router} from '@angular/router';
import { Platform } from '@ionic/angular';

@Component({
  selector: 'app-mescannaux',
  templateUrl: './mescannaux.page.html',
  styleUrls: ['./mescannaux.page.scss'],
  standalone:false
})
export class MescannauxPage implements OnInit {

  //@viewChild('iframeProfil',{static:false}) iframe:ElementRef;

  public etat=0;
  public etatmobile=window.innerWidth;

  textValue:string='';



  tabl=[{id:1,detail:"junior"},{id:2,detail:"joseph"},{id:3,detail:"askyas"}];
  
  tabnew=[{id:1,detail:"junior"},{id:2,detail:"joseph"},{id:3,detail:"askyas"},{id:1,detail:"junior"},{id:2,detail:"joseph"},{id:3,detail:"askyas"},{id:1,detail:"junior"},{id:2,detail:"joseph"},{id:3,detail:"askyas"}];

  tabActualite1=["Lancement Projet","Annulation contrat minier","Approbation legale de montant"];

  //tabTitre=["Lancement Officiel de la Promotion de Carte de Visite Porfesionnel","Promotion sur le Logiciel SUPER PHARMA dans le cadre d'encourager les Gestionnaire","Lancement Officiel sur la conception Maquette Pro dans le sens de Booster la Visibilté des entreprises"]

  tabTitre=["Le PDG de la C.T.I  Lance La Promotion de Carte(Carte Simple, CArte PVC)=> 15% de REDUCTION","La C.T.I reprend les Activités de Formation Professionnelle pour la Nouvelle Edition 2025 ","La Division de Marketing signal la Promotion du LOGICIEL SUPER PHARMA Tend à sa fin"]

  
  textt="";

  tabinfo=[
    {nomSysteme:"AaskyaGUEST"}
  ];

  frameProfil:string="/profil";


  constructor(private router:Router){
    //alert(this.etatmobile);
  }


  ngOnInit() {
  }

  tester(){
    
    alert(document.getElementById('item2')!.innerText);
  }

  compteur(){

    alert(this.textValue.length);
  
  }

  tirerMenu(){

    //document.getElementById('menuu')!.style.backgroundColor="red";

    if(this.etat==1){ 

      document.getElementById('menu0')!.style.height="50px";
      document.getElementById('menu0')!.style.width="50px";

      document.getElementById('menu1')!.style.height="0%";
      document.getElementById('menu1')!.style.width="0%";

      document.getElementById('menu1')!.style.display="none";

      //document.getElementById('menu2')!.style.height="100%";
      //document.getElementById('menu2')!.style.width="100%";

      //document.getElementById('unitilmenu2')!.style.width="0%";
      //document.getElementById('unitilmenu2')!.style.height="0%";

      this.etat=0;
    }

    else{
      
      document.getElementById('menu0')!.style.height="800px";
      document.getElementById('menu0')!.style.width="98%";

      document.getElementById('menu1')!.style.height="100%";
      document.getElementById('menu1')!.style.width="80%";

      document.getElementById('menu2')!.style.height="50px";
      document.getElementById('menu2')!.style.width="18%";

      document.getElementById('menu1')!.style.display="inline-block";
      document.getElementById('menu2')!.style.display="inline-block";

      document.getElementById('menu1')?.scrollIntoView({behavior:'smooth'});

      //document.getElementById('unitilmenu2')!.style.width="100%";
      //document.getElementById('unitilmenu2')!.style.height="90%";

      //document.getElementById('menu2')!.style.display="block";

      this.etat=1;
    }
  }
  

  atteindreACtualite(){

    //alert("rien new");

    if(this.etatmobile < 600){

      
      //this.router.navigate(['/contenu1',{fragment:'section1'}]);

      document.getElementById('section1')!.style.display="block";
      document.getElementById('section2')!.style.display="none";
      document.getElementById('section3')!.style.display="none";
      document.getElementById('section4')!.style.display="none";
      document.getElementById('section5')!.style.display="none";

      document.getElementById('menu0')!.style.height="50px";
      document.getElementById('menu0')!.style.width="50px";

      document.getElementById('menu1')!.style.height="0%";
      document.getElementById('menu1')!.style.width="0%";

      document.getElementById('menu1')!.style.display="none";

    }
    else{

      document.getElementById('section1')!.style.display="block";
      document.getElementById('section2')!.style.display="none";
      document.getElementById('section3')!.style.display="none";
      document.getElementById('section4')!.style.display="none";
      document.getElementById('section5')!.style.display="none";

    }
  
  }

  atteindreService(){

    //this.router.navigate(['/mescannaux',{fragment:'section1'}]);
    if(this.etatmobile < 600){
        
      document.getElementById('section1')!.style.display="none";
      document.getElementById('section2')!.style.display="block";
      document.getElementById('section3')!.style.display="none";
      document.getElementById('section4')!.style.display="none";
      document.getElementById('section5')!.style.display="none";
      

      document.getElementById('menu0')!.style.height="50px";
      document.getElementById('menu0')!.style.width="50px";

      document.getElementById('menu1')!.style.height="0%";
      document.getElementById('menu1')!.style.width="0%";

      document.getElementById('menu1')!.style.display="none";
    }
    else{

      document.getElementById('section1')!.style.display="none";
      document.getElementById('section2')!.style.display="block";
      document.getElementById('section3')!.style.display="none";
      document.getElementById('section4')!.style.display="none";
      document.getElementById('section5')!.style.display="none";

    }
  }

  atteindrePartenariat(){

    //this.router.navigate(['/mescannaux',{fragment:'section1'}]);

    if(this.etatmobile < 600){
        
      document.getElementById('section1')!.style.display="none";
      document.getElementById('section2')!.style.display="none";
      document.getElementById('section3')!.style.display="block";
      document.getElementById('section4')!.style.display="none";
      document.getElementById('section5')!.style.display="none";

      document.getElementById('menu0')!.style.height="50px";
      document.getElementById('menu0')!.style.width="50px";

      document.getElementById('menu1')!.style.height="0%";
      document.getElementById('menu1')!.style.width="0%";

      document.getElementById('menu1')!.style.display="none";
    }
    else{

      document.getElementById('section1')!.style.display="none";
      document.getElementById('section2')!.style.display="none";
      document.getElementById('section3')!.style.display="block";
      document.getElementById('section4')!.style.display="none";
      document.getElementById('section5')!.style.display="none";

    }
  
  }

  atteindreVenteProjet(){

    // this.router.navigate(['/mescannaux',{fragment:'section1'}]);

    if(this.etatmobile < 600){
        
      document.getElementById('section1')!.style.display="none";
      document.getElementById('section2')!.style.display="none";
      document.getElementById('section3')!.style.display="none";
      document.getElementById('section4')!.style.display="block";
      document.getElementById('section5')!.style.display="none";

      document.getElementById('menu0')!.style.height="50px";
      document.getElementById('menu0')!.style.width="50px";

      document.getElementById('menu1')!.style.height="0%";
      document.getElementById('menu1')!.style.width="0%";

      document.getElementById('menu1')!.style.display="none";
    }
    else{

      document.getElementById('section1')!.style.display="none";
      document.getElementById('section2')!.style.display="none";
      document.getElementById('section3')!.style.display="none";
      document.getElementById('section4')!.style.display="block";
      document.getElementById('section5')!.style.display="none";

    }
  
  }

  atteindreContact(){

    //this.router.navigate(['/mescannaux',{fragment:'section1'}]);

    if(this.etatmobile < 600){
        
      document.getElementById('section1')!.style.display="none";
      document.getElementById('section2')!.style.display="none";
      document.getElementById('section3')!.style.display="none";
      document.getElementById('section4')!.style.display="none";
      document.getElementById('section5')!.style.display="block";

      document.getElementById('menu0')!.style.height="50px";
      document.getElementById('menu0')!.style.width="50px";

      document.getElementById('menu1')!.style.height="0%";
      document.getElementById('menu1')!.style.width="0%";

      document.getElementById('menu1')!.style.display="none";

    }
    else{

      document.getElementById('section1')!.style.display="none";
      document.getElementById('section2')!.style.display="none";
      document.getElementById('section3')!.style.display="none";
      document.getElementById('section4')!.style.display="none";
      document.getElementById('section5')!.style.display="block";

    }  
  }


  //[routerLink]="'/profil'" [routerLink]="'/profil-edit'"

  chargeProfil(){
    
    this.frameProfil="/profil-edit";
    

  }

}
