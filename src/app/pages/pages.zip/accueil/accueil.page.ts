import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-accueil',
  templateUrl: './accueil.page.html',
  styleUrls: ['./accueil.page.scss'],
  standalone:false
})
export class AccueilPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  suggestion(){
    
  }

}
