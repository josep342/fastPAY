import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { PartenariatPageRoutingModule } from './partenariat-routing.module';

import { PartenariatPage } from './partenariat.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    PartenariatPageRoutingModule
  ],
  declarations: [PartenariatPage]
})
export class PartenariatPageModule {}
