import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-partenariat',
  templateUrl: './partenariat.page.html',
  styleUrls: ['./partenariat.page.scss'],
  standalone:false
})
export class PartenariatPage implements OnInit {

  tabTitre=["Le Partenariat d'affaire reflete une collaboration entre deux entreprises quelque soit le domaine de cette dernière"];
  tabTitreCle=["En Suisse de ce raisonnement, le partenariat d'affaire facilite une entreprise de collaborer avec la CHAMBRE TECHNIQUE INFORMATIQUE sous differentes formes tout en respectant le principe d'accord convenus"];
  tabTitreDetail=["Cette dimension enrichisse la relation d 'affaire jusqu'à se partager les machés, les projets, ressources humaines, ressources matérielles tout en négociant une marge d'affaire et se rassurer que tou t est respecter selon l'engagement de deux parties,De ce fait signalons que nous collaborons avec toutes sortes d'entreprises(Publique, Privée, Moyenne,Petite et Grande) Pour PLus d'info contacter le support +243 823382732"]
  
  tabTitreCop=["La Coopération Mutuelle reflete une collaboration entre deux Entités, quelque soit le domaine de cette dernière"];
  tabTitreCleCop=["Partant de l'idée, la Coopération Mutuelle facilite un particulier de collaborer avec la CHAMBRE TECHNIQUE INFORMATIQUE sous differentes formes tout en respectant le principe d'accord convenus"];
  tabTitreDetailCop=["Cette dimension enrichisse la relation d 'affaire entre Entreprise(C.T.I.) et un Particulier jusqu'à se partager les machés, les projets, ressources humaines, ressources matérielles tout en négociant une marge d'affaire et se rassurer que tou t est respecter selon l'engagement de deux parties,De ce fait signalons que nous collaborons avec toutes sortes d'entreprises(Publique, Privée, Moyenne,Petite et Grande) Pour PLus d'info contacter le support +243 823382732"]
  
  constructor() { }

  ngOnInit() {
  }

}
