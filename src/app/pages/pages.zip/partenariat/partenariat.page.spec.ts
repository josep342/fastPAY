import { ComponentFixture, TestBed } from '@angular/core/testing';
import { PartenariatPage } from './partenariat.page';

describe('PartenariatPage', () => {
  let component: PartenariatPage;
  let fixture: ComponentFixture<PartenariatPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(PartenariatPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
