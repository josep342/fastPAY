import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vente-projet',
  templateUrl: './vente-projet.page.html',
  styleUrls: ['./vente-projet.page.scss'],
  standalone:false,
 
})
export class VenteProjetPage implements OnInit {

  tabTitre=["Conception de Logiciels de Gestion des Entreprises Modernes","Conception de SITE WEB Profesionnel pour la Visibilité des Entreprises","Conception et Impression de Maquette Profesionnel pour Booster la Visibilté des Entreprises et ses Produit"]

  tabTitreCle=[" Cette promotion est dans lme cadre de la cco,cepton des appareeil de la cement oficielle de la promotionnde la concenption Lancement Officiel de la Promotion de Carte de Visite"," L chmabre Technique infiormatique de LInshasa lance une promotion sur la le Logicciel SUPRT PHARMA capable de gere la pharlacie en temps reel Lancement sur le Logiciel SUPER PHARMA"," Notre ENyreprise a ele reel plaisir srv ous annoncer la prtomotion dir ma creattion de site prfesisonnel capable de booster la visi=bilité de la entreprie et capàable de bous fournir une epirsentatin "]

  tabTitreDetail=[" en vrai nitre entreprie et capable de vous founrinun emaruqttte de complettion de excacrivibe de ka manquete  de kla conseetion de la siec d  Cette promotion est dans lme cadre de la cco,cepton des appareeil de la cement oficielle de la promotionnde la concenption Lancement Officiel de la Promotion de Carte de Visite en vrai nitre entreprie et capable de vous founrinun emaruqttte de complettion de excacrivibe de ka manquete  de kla conseetion de la siec d  Cette promotion est dans lme cadre de la cco,cepton des appareeil de la cement oficielle de la promotionnde la concenption Lancement Officiel de la Promotion de Carte de Visite","chmabre Technique infiormatique de LInshasa lance une promotion sur la le Logicciel SUPRT PHARMA capable de gere la pharlacie en temps reel Lancement sur le Logiciel SUPER PHARMA en vrai nitre entreprie et capable de vous founrinun emaruqttte de complettion de excacrivibe de ka manquete  de kla conseetion de la siec d  Cette promotion est dans lme cadre de la cco,cepton des appareeil de la cement oficielle de la promotionnde la concenption Lancement Officiel de la Promotion de Carte de Visite"," en vrai nitre entreprie et capable de vous founrinun emaruqttte de complettion de excacrivibe de ka manquete  de kla conseetion de la siec d  Cette promotion est dans lme cadre de la cco,cepton des appareeil de la cement oficielle de la promotionnde la concenption Lancement Officiel de la Promotion de Carte de Visite Notre ENyreprise a ele reel plaisir srv ous annoncer la prtomotion dir ma creattion de site prfesisonnel capable de booster la visi=bilité de la entreprie et capàable de bous fournir une epirsentatin de la maniretirque et la ratiobalisement e kla completationde tionacalt t ecvaepLancement Officiel sur la conception Maquette Pro "]

  tabImage=["/assets/images/bas3.jpg","/assets/images/bas4.png","/assets/images/c3.jpeg"];
  

  tabTitreSite=["Depnnages Materiels(Maintenance PC, Routeur,Imprimante et autres)","Depannages Logiciels(Maintenance OS et autres)","Checking et Analyses de Fails de Systeme des Entreprises"]

  tabTitreCleSite=[" Cette promotion est dans lme cadre de la cco,cepton des appareeil de la cement oficielle de la promotionnde la concenption Lancement Officiel de la Promotion de Carte de Visite"," L chmabre Technique infiormatique de LInshasa lance une promotion sur la le Logicciel SUPRT PHARMA capable de gere la pharlacie en temps reel Lancement sur le Logiciel SUPER PHARMA"," Notre ENyreprise a ele reel plaisir srv ous annoncer la prtomotion dir ma creattion de site prfesisonnel capable de booster la visi=bilité de la entreprie et capàable de bous fournir une epirsentatin "]

  tabTitreDetailSite=[" en vrai nitre entreprie et capable de vous founrinun emaruqttte de complettion de excacrivibe de ka manquete  de kla conseetion de la siec d  Cette promotion est dans lme cadre de la cco,cepton des appareeil de la cement oficielle de la promotionnde la concenption Lancement Officiel de la Promotion de Carte de Visite en vrai nitre entreprie et capable de vous founrinun emaruqttte de complettion de excacrivibe de ka manquete  de kla conseetion de la siec d  Cette promotion est dans lme cadre de la cco,cepton des appareeil de la cement oficielle de la promotionnde la concenption Lancement Officiel de la Promotion de Carte de Visite","chmabre Technique infiormatique de LInshasa lance une promotion sur la le Logicciel SUPRT PHARMA capable de gere la pharlacie en temps reel Lancement sur le Logiciel SUPER PHARMA en vrai nitre entreprie et capable de vous founrinun emaruqttte de complettion de excacrivibe de ka manquete  de kla conseetion de la siec d  Cette promotion est dans lme cadre de la cco,cepton des appareeil de la cement oficielle de la promotionnde la concenption Lancement Officiel de la Promotion de Carte de Visite"," en vrai nitre entreprie et capable de vous founrinun emaruqttte de complettion de excacrivibe de ka manquete  de kla conseetion de la siec d  Cette promotion est dans lme cadre de la cco,cepton des appareeil de la cement oficielle de la promotionnde la concenption Lancement Officiel de la Promotion de Carte de Visite Notre ENyreprise a ele reel plaisir srv ous annoncer la prtomotion dir ma creattion de site prfesisonnel capable de booster la visi=bilité de la entreprie et capàable de bous fournir une epirsentatin de la maniretirque et la ratiobalisement e kla completationde tionacalt t ecvaepLancement Officiel sur la conception Maquette Pro "]

  tabImageSite=["/assets/images/bas3.jpg","/assets/images/bas4.png","/assets/images/c3.jpeg"];
  

  tabTitreAutre=["Formation accelerée en Creation des APP DeskTop, Mobile et SITE WEB Pro","Formation accelerée en MOntage PHOTO et VIDEO(Maquettes Pro, Production Clip)","Formation accelerée en Bureautique(Word,Excel des Entreprises, PowerPOint,..."]

  tabTitreCleAutre=[" Cette promotion est dans lme cadre de la cco,cepton des appareeil de la cement oficielle de la promotionnde la concenption Lancement Officiel de la Promotion de Carte de Visite"," L chmabre Technique infiormatique de LInshasa lance une promotion sur la le Logicciel SUPRT PHARMA capable de gere la pharlacie en temps reel Lancement sur le Logiciel SUPER PHARMA"," Notre ENyreprise a ele reel plaisir srv ous annoncer la prtomotion dir ma creattion de site prfesisonnel capable de booster la visi=bilité de la entreprie et capàable de bous fournir une epirsentatin "]

  tabTitreDetailAutre=[" en vrai nitre entreprie et capable de vous founrinun emaruqttte de complettion de excacrivibe de ka manquete  de kla conseetion de la siec d  Cette promotion est dans lme cadre de la cco,cepton des appareeil de la cement oficielle de la promotionnde la concenption Lancement Officiel de la Promotion de Carte de Visite en vrai nitre entreprie et capable de vous founrinun emaruqttte de complettion de excacrivibe de ka manquete  de kla conseetion de la siec d  Cette promotion est dans lme cadre de la cco,cepton des appareeil de la cement oficielle de la promotionnde la concenption Lancement Officiel de la Promotion de Carte de Visite","chmabre Technique infiormatique de LInshasa lance une promotion sur la le Logicciel SUPRT PHARMA capable de gere la pharlacie en temps reel Lancement sur le Logiciel SUPER PHARMA en vrai nitre entreprie et capable de vous founrinun emaruqttte de complettion de excacrivibe de ka manquete  de kla conseetion de la siec d  Cette promotion est dans lme cadre de la cco,cepton des appareeil de la cement oficielle de la promotionnde la concenption Lancement Officiel de la Promotion de Carte de Visite"," en vrai nitre entreprie et capable de vous founrinun emaruqttte de complettion de excacrivibe de ka manquete  de kla conseetion de la siec d  Cette promotion est dans lme cadre de la cco,cepton des appareeil de la cement oficielle de la promotionnde la concenption Lancement Officiel de la Promotion de Carte de Visite Notre ENyreprise a ele reel plaisir srv ous annoncer la prtomotion dir ma creattion de site prfesisonnel capable de booster la visi=bilité de la entreprie et capàable de bous fournir une epirsentatin de la maniretirque et la ratiobalisement e kla completationde tionacalt t ecvaepLancement Officiel sur la conception Maquette Pro "]

  tabImageAutre=["/assets/images/bas3.jpg","/assets/images/bas4.png","/assets/images/c3.jpeg"];

  
  constructor() { } 

  ngOnInit() {
  }

}
