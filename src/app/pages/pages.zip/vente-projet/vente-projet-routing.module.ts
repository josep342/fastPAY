import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { VenteProjetPage } from './vente-projet.page';

const routes: Routes = [
  {
    path: '',
    component: VenteProjetPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class VenteProjetPageRoutingModule {}
