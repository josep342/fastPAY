import { ComponentFixture, TestBed } from '@angular/core/testing';
import { VenteProjetPage } from './vente-projet.page';

describe('VenteProjetPage', () => {
  let component: VenteProjetPage;
  let fixture: ComponentFixture<VenteProjetPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(VenteProjetPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
