import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { VenteProjetPageRoutingModule } from './vente-projet-routing.module';

import { VenteProjetPage } from './vente-projet.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    VenteProjetPageRoutingModule
  ],
  declarations: [VenteProjetPage]
})
export class VenteProjetPageModule {}
