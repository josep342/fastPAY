import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-createcompte',
  templateUrl: './createcompte.page.html',
  styleUrls: ['./createcompte.page.scss'],
  standalone:false
})
export class CreatecomptePage implements OnInit {

  tabl=[{id:1,detail:"junior"},{id:2,detail:"joseph"},{id:3,detail:"askyas"},{id:1,detail:"junior"},{id:2,detail:"joseph"},{id:3,detail:"askyas"},{id:1,detail:"junior"},{id:2,detail:"joseph"},{id:3,detail:"askyas"},{id:1,detail:"junior"},{id:2,detail:"joseph"},{id:3,detail:"askyas"},{id:1,detail:"junior"},{id:2,detail:"joseph"},{id:3,detail:"askyas"},{id:1,detail:"junior"}];

  constructor() { }

  ngOnInit() {
  }

}
