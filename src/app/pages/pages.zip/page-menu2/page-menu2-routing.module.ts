import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PageMenu2Page } from './page-menu2.page';

const routes: Routes = [
  {
    path: '',
    component: PageMenu2Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class PageMenu2PageRoutingModule {}
