import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { PageMenu2PageRoutingModule } from './page-menu2-routing.module';

import { PageMenu2Page } from './page-menu2.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    PageMenu2PageRoutingModule
  ],
  declarations: [PageMenu2Page]
})
export class PageMenu2PageModule {}
