import { ComponentFixture, TestBed } from '@angular/core/testing';
import { PageMenu2Page } from './page-menu2.page';

describe('PageMenu2Page', () => {
  let component: PageMenu2Page;
  let fixture: ComponentFixture<PageMenu2Page>;

  beforeEach(() => {
    fixture = TestBed.createComponent(PageMenu2Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
