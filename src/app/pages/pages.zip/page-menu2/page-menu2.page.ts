import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-menu2',
  templateUrl: './page-menu2.page.html',
  styleUrls: ['./page-menu2.page.scss'],
  standalone: false,
})
export class PageMenu2Page implements OnInit {


  tabActualite1=["Lancement Projet","Annulation contrat minier","Approbation legale de montant","Lancement Projet","Annulation contrat minier","Approbation legale de montant"];

  tabTitre=["Lancement Officiel de la Promotion de Carte de Visite Porfesionnel","Promotion sur le Logiciel SUPER PHARMA dans le cadre d'encourager les Gestionnaire","Lancement Officiel sur la conception Maquette Pro dans le sens de Booster la Visibilté des entreprises"]

  
  constructor() { }

  ngOnInit() {
  }

  suggestion(){
    
  }

}
