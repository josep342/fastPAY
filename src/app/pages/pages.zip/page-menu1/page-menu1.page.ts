import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';

@Component({
  selector: 'app-page-menu1',
  templateUrl: './page-menu1.page.html',
  styleUrls: ['./page-menu1.page.scss'],
  standalone: false,
})
export class PageMenu1Page implements OnInit {

  //let tab;

  tabActualite1=["Lancement Projet","Annulation contrat minier","Approbation legale de montant"];

  tabTitre=["Lancement Officiel de la Promotion de Carte de Visite Porfesionnel","Promotion sur le Logiciel SUPER PHARMA dans le cadre d'encourager les Gestionnaire","Lancement Officiel sur la conception Maquette Pro dans le sens de Booster la Visibilté des entreprises"]

  constructor(private router:Router){}

  ngOnInit() {
  }

  suggestion(){
    
  }

  atteindreACtualite(){

    this.router.navigate(['/mescannaux',{fragment:'section1'}]);

    //document.getElementById('menu0')!.style.height="50px";
    //document.getElementById('menu0')!.style.width="50px";

    //document.getElementById('menu1')!.style.height="0%";
    //document.getElementById('menu1')!.style.width="0%";

    //document.getElementById('menu1')!.style.display="none";
    
  }

}
