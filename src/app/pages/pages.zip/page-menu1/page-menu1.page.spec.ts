import { ComponentFixture, TestBed } from '@angular/core/testing';
import { PageMenu1Page } from './page-menu1.page';

describe('PageMenu1Page', () => {
  let component: PageMenu1Page;
  let fixture: ComponentFixture<PageMenu1Page>;

  beforeEach(() => {
    fixture = TestBed.createComponent(PageMenu1Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
