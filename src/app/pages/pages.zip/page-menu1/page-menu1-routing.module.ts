import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PageMenu1Page } from './page-menu1.page';

const routes: Routes = [
  {
    path: '',
    component: PageMenu1Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class PageMenu1PageRoutingModule {}
