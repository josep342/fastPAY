import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { PageMenu1PageRoutingModule } from './page-menu1-routing.module';

import { PageMenu1Page } from './page-menu1.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    PageMenu1PageRoutingModule
  ],
  declarations: [PageMenu1Page]
})
export class PageMenu1PageModule {}
