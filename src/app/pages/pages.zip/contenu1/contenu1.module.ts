import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Contenu1PageRoutingModule } from './contenu1-routing.module';

import { Contenu1Page } from './contenu1.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Contenu1PageRoutingModule
  ],
  declarations: [Contenu1Page]
})
export class Contenu1PageModule {}
