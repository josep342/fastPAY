import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Contenu1Page } from './contenu1.page';

const routes: Routes = [
  {
    path: '',
    component: Contenu1Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Contenu1PageRoutingModule {}
