import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Contenu1Page } from './contenu1.page';

describe('Contenu1Page', () => {
  let component: Contenu1Page;
  let fixture: ComponentFixture<Contenu1Page>;

  beforeEach(() => {
    fixture = TestBed.createComponent(Contenu1Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
