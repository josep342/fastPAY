import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contenu1',
  templateUrl: './contenu1.page.html',
  styleUrls: ['./contenu1.page.scss'],
  standalone:false
})
export class Contenu1Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
