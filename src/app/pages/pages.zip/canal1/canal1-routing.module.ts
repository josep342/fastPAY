import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Canal1Page } from './canal1.page';

const routes: Routes = [
  {
    path: '',
    component: Canal1Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Canal1PageRoutingModule {}
